//
//  meals.swift
//  2210994811_Test2
//
//  Created by Mayank Dhankhar on 23/11/24.
//

import Foundation
import UIKit

struct Meal {
    let recipeName : String
    let calorieCount : Int
    let preparationTime : String
    let image : UIImage
    let ingredients : [String]
    let preparationInstructions : String
    let category : String
    let nutritionalInfo : String
}

