//
//  mealListTableViewCell.swift
//  2210994811_Test2
//
//  Created by Mayank Dhankhar on 23/11/24.
//

import UIKit

class mealListTableViewCell: UITableViewCell {
    
    @IBOutlet weak var mealImage: UIImageView!
    
    @IBOutlet weak var recipeName: UILabel!
    
    @IBOutlet weak var calorieCount: UILabel!
    
    
    @IBOutlet weak var preparationTime: UILabel!
    
    
    func configure(with meal: Meal) {
            recipeName.text = meal.recipeName
            calorieCount.text = "\(meal.calorieCount) kcal"
            preparationTime.text = meal.preparationTime
            mealImage.image = meal.image
        }

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
